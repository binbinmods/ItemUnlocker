# 1.0.4

Added option to remove all starter items

# 1.0.3

Added protection for null heroes.

# 1.0.2

Update for AtO v1.6.22 (post-patch)

# 1.0.1

Removed the upgraded versions of starter items from the pool. Can still purchase unupgraded versions.

Fixed Essentials Compatibility

# 1.0.0

Initial release.
